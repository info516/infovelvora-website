import Head from 'next/head';

export default function Home() {
  return (
    <div>
      <Head>
        <title>Infovelvora LLC</title>
        <meta name="description" content="Infovelvora LLC - E-commerce solutions" />
      </Head>
      <main className="min-h-screen bg-white">
        <header className="bg-blue-900 text-white p-6 text-center text-3xl font-bold">
          Infovelvora LLC
        </header>
        <section className="p-10 text-center">
          <h1 className="text-4xl font-bold">Welcome to Infovelvora LLC</h1>
          <p className="mt-4 text-lg">We specialize in global e-commerce solutions and Amazon integration.</p>
          <a href="#" className="inline-block mt-6 px-6 py-3 bg-blue-800 text-white rounded hover:bg-blue-600">Visit Amazon Store</a>
        </section>
        <footer className="bg-gray-900 text-white p-6 mt-20 text-center">
          &copy; {new Date().getFullYear()} Infovelvora LLC. All rights reserved.
        </footer>
      </main>
    </div>
  )
}
