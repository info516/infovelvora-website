
export default function About() {
  return (
    <div className="p-10">
      <h1 className="text-3xl font-bold">About Infovelvora LLC</h1>
      <p className="mt-4 text-gray-600">
        Infovelvora LLC provides cross-border e-commerce solutions, specializing in Amazon sales and logistics.
      </p>
    </div>
  );
}
