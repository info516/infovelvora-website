
import Head from 'next/head';
import Link from 'next/link';

export default function Home() {
  return (
    <div>
      <Head>
        <title>Infovelvora LLC</title>
        <meta name="description" content="Infovelvora LLC - Global E-commerce Solutions" />
      </Head>
      <header className="bg-blue-900 text-white p-5 text-center text-2xl font-bold">
        Infovelvora LLC
      </header>
      <main className="p-10 text-center">
        <h1 className="text-4xl font-bold">Innovating Tomorrow, Today</h1>
        <p className="mt-4 text-lg text-gray-600">
          Infovelvora LLC specializes in Amazon sales, e-commerce, and global logistics solutions.
        </p>
        <div className="mt-6 space-x-4">
          <Link href="/about" className="bg-blue-600 text-white px-5 py-2 rounded-md">About Us</Link>
          <Link href="/services" className="bg-gray-700 text-white px-5 py-2 rounded-md">Our Services</Link>
          <Link href="/contact" className="bg-green-600 text-white px-5 py-2 rounded-md">Contact</Link>
        </div>
      </main>
    </div>
  );
}
