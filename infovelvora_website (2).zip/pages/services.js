
export default function Services() {
  return (
    <div className="p-10">
      <h1 className="text-3xl font-bold">Our Services</h1>
      <ul className="mt-4 list-disc pl-5 text-gray-600">
        <li>Amazon Global Store Management</li>
        <li>Cross-Border E-commerce Solutions</li>
        <li>International Logistics & Fulfillment</li>
      </ul>
    </div>
  );
}
