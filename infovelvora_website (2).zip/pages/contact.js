
export default function Contact() {
  return (
    <div className="p-10">
      <h1 className="text-3xl font-bold">Contact Us</h1>
      <form className="mt-6 space-y-4 max-w-md">
        <input type="text" placeholder="Your Name" className="border w-full p-2 rounded" />
        <input type="email" placeholder="Your Email" className="border w-full p-2 rounded" />
        <textarea placeholder="Your Message" className="border w-full p-2 rounded"></textarea>
        <button className="bg-blue-600 text-white px-5 py-2 rounded">Send Message</button>
      </form>
    </div>
  );
}
