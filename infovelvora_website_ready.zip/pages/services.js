
export default function Services() {
  return (
    <div className="p-10 bg-gray-50 min-h-screen">
      <h1 className="text-4xl font-bold mb-4">Our Services</h1>
      <ul className="list-disc pl-6 text-lg">
        <li>Business Consulting</li>
        <li>Digital Marketing Solutions</li>
        <li>E-commerce Management</li>
        <li>Software Development</li>
      </ul>
    </div>
  );
}
