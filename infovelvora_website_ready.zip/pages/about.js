
export default function About() {
  return (
    <div className="p-10 bg-gray-50 min-h-screen">
      <h1 className="text-4xl font-bold mb-4">About Infovelvora LLC</h1>
      <p className="text-lg leading-relaxed">
        At Infovelvora LLC, we are passionate about delivering high-quality solutions to empower businesses worldwide.
        Our mission is to create innovative services that drive growth and success.
      </p>
    </div>
  );
}
