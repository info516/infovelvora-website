
import Head from 'next/head';
import Link from 'next/link';

export default function Home() {
  return (
    <div>
      <Head>
        <title>Infovelvora LLC</title>
        <meta name="description" content="Infovelvora LLC - Innovative Solutions for Your Business" />
      </Head>
      <main className="flex flex-col items-center justify-center min-h-screen bg-gray-50 text-gray-900">
        <h1 className="text-5xl font-bold mb-6">Welcome to Infovelvora LLC</h1>
        <p className="text-lg mb-4 text-center w-2/3">
          Infovelvora LLC delivers innovative solutions and services to help businesses grow worldwide.
        </p>
        <div className="flex gap-6 mt-6">
          <Link href="/about" className="px-6 py-3 bg-blue-600 text-white rounded-lg shadow-md hover:bg-blue-700">About Us</Link>
          <Link href="/services" className="px-6 py-3 bg-green-600 text-white rounded-lg shadow-md hover:bg-green-700">Services</Link>
          <Link href="/contact" className="px-6 py-3 bg-gray-700 text-white rounded-lg shadow-md hover:bg-gray-800">Contact</Link>
        </div>
      </main>
    </div>
  );
}
